#!/bin/bash

export QTDIR=.
export PATH=${QTDIR}:${PATH}
export LD_LIBRARY_PATH=${QTDIR}/lib:${LD_LIBRARY_PATH}
export QT_QPA_PLATFORM_PLUGIN_PATH=${QTDIR}/plugins
#export QT_DEBUG_PLUGINS=1


./SongExplorer "$@"

