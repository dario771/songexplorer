#!/bin/bash
# Installa SongExplorer in /home/utente/SongExplorer e crea un icona sul desktop
dest_dir="$HOME/SongExplorer"

# La creazione del .desktop è stata provata su OpenSuse, Ubuntu. Ubuntu mette come prima riga: #!/usr/bin/env xdg-open
# Per sapre se è corretto il file .desktop fare "desktop-file-validate <file.dektop>"
# Per trovare spiegazioni: https://wiki.archlinux.org/index.php/Desktop_entries
creadesk() {
  echo "[Desktop Entry]" > "$file_desktop"
  echo "Version=1.0" >> "$file_desktop"
  echo "Comment=SongExplorer" >> "$file_desktop"
  echo "Exec=\"$dest_dir/SongExplorer.sh\"" >> "$file_desktop"
  echo "Icon=$dest_dir/SongExplorer.png" >> "$file_desktop"
  echo "Name=SongExplorer" >> "$file_desktop"
  echo "Path=$dest_dir/" >> "$file_desktop"
  echo "Terminal=false" >> "$file_desktop"
  echo "Type=Application" >> "$file_desktop"
  chmod ugo+x "$file_desktop"
}

echo "Installo SongExplorer in $HOME/SongExplorer e creo icona sul Desktop"
if [ "$PWD" != "$HOME" ]
then
    cp -r SongExplorer "$HOME"
    if [ $? -ne 0 ] 
    then
      echo "Installazione non riuscita"
      exit 1
    fi
fi

# Devo creare i link alle librerie openSSL perchè in alcuni sistemi serve
PDIR=`echo $PWD`
cd "$HOME/SongExplorer/lib"
if [ ! -f libssl.so ]
then 
    ln -s libssl.so.1.0.0 libssl.so
    ln -s libssl.so.1.0.0 libssl.so.1
    ln -s libcrypto.so.1.0.0 libcrypto.so.1
    ln -s libcrypto.so.1.0.0 libcrypto.so
fi
cd $PDIR

rm "$HOME/SongExplorer/install.sh"


#La definizioni di tutte le cartelle dovrebbero essere su $HOME/.config/user-dirs.dirs, quella del Desktop è
#XDG_DESKTOP_DIR... Ci sono i comandi xdg ...
file_desktop=`xdg-user-dir DESKTOP`
if [ ! -z "$file_desktop" ]
then
    # Stringa non vuota, controllo se esiste la cartella
    if [ -d "$file_desktop" ]; then
	file_desktop=$file_desktop/SongExplorer.desktop
    else
	file_desktop=
    fi
fi

# Se la cartella presa da xdg non esiste, provo con i classici nomi
# in inglese/italiano/spagnolo/francese/tedesco
if [ -z "$file_desktop" ]
then
	if [ -d "$HOME/Desktop" ]; then
	  file_desktop=$HOME/Desktop/SongExplorer.desktop
	fi
	if [ -d "$HOME/Scrivania" ]; then
	  file_desktop=$HOME/Scrivania/SongExplorer.desktop
	fi
	if [ -d "$HOME/Escritorio" ]; then
	  file_desktop=$HOME/Escritorio/SongExplorer.desktop
	fi
	if [ -d "$HOME/Bureau" ]; then
	  file_desktop=$HOME/Bureau/SongExplorer.desktop
	fi
fi

if [ ! -z "$file_desktop" ]
then
    echo "Creo icona sul desktop ($file_desktop)"
    creadesk
fi

# Creo icona nella lista dei programmi
if [ -d  "$HOME/.local/share/applications" ]; then
  file_desktop=$HOME/.local/share/applications/SongExplorer.desktop
  creadesk
else
  mkdir "$HOME/.local/share/applications"
  file_desktop=$HOME/.local/share/applications/SongExplorer.desktop
  creadesk
fi

if [ "$PWD" != "$HOME" ]
then
    rm -r SongExplorer
fi
