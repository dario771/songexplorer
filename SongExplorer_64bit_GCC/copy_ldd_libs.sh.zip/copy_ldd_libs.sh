#!/bin/bash

# Script to copy dynamic libraries required by an executable to a destination folder.

# Initialize variables
COPY_SYSTEM_LIBS=false
DEST_FOLDER=""
EXECUTABLE_FILES=()

# --- Argument Parsing ---

# Check for minimum arguments: at least one executable and the destination folder
if [ "$#" -lt 2 ]; then
    echo "Usage: $0 <executable1> [executable2...] <destination_folder> [-system-lib]"
    echo "  <executable1> [executable2...]: One or more executable files."
    echo "  <destination_folder>: The folder where libraries will be copied."
    echo "  -system-lib: Optional flag to copy system libraries (e.g., from /usr/lib, /lib) as well."
    exit 1
fi

# Check if the last argument is -system-lib
last_arg="${!#}" # Get the value of the last argument
if [ "$last_arg" == "-system-lib" ]; then
    COPY_SYSTEM_LIBS=true
    # Adjust the total number of effective arguments (excluding -system-lib)
    num_effective_args=$(($#-1))
    echo "'-system-lib' flag detected. All libraries will be copied, including system ones."
else
    COPY_SYSTEM_LIBS=false
    num_effective_args="$#"
fi

# The destination folder is now the last effective argument
DEST_FOLDER="${!num_effective_args}"

# Validate that there's at least one executable file before the destination folder
if [ "$((num_effective_args-1))" -lt 1 ]; then
    echo "Error: No executable files provided. The destination folder cannot be the only argument (or only remaining argument after -system-lib)."
    echo "Usage: $0 <executable1> [executable2...] <destination_folder> [-system-lib]"
    exit 1
fi

# Collect all executable files
for i in $(seq 1 "$((num_effective_args-1))"); do
    EXECUTABLE_FILES+=("${!i}")
done

# --- End Argument Parsing ---

LIBRARIES_LIST_FILE="$DEST_FOLDER/ldd_libraries.txt"

# Validate destination folder
if [ ! -d "$DEST_FOLDER" ]; then
    echo "Error: Destination folder '$DEST_FOLDER' not found."
    exit 1
fi

echo "Destination folder: $DEST_FOLDER"
echo "List of copied libraries will be saved to: $LIBRARIES_LIST_FILE"
echo "---"

# Function to check if a library path is a system library
is_system_lib() {
    local lib_path="$1"
    case "$lib_path" in
        /usr/lib/* | /usr/lib64/* | /lib/* | /lib64/*)
            return 0 # It is a system lib
            ;;
        *)
            return 1 # It is NOT a system lib
            ;;
    esac
}

# Clear previous list if it exists (only once at the beginning)
> "$LIBRARIES_LIST_FILE"

# --- Main processing loop for each executable ---
for EXECUTABLE in "${EXECUTABLE_FILES[@]}"; do
    echo "--- Processing executable: $EXECUTABLE ---"

    # Validate executable file
    if [ ! -f "$EXECUTABLE" ]; then
        echo "Error: Executable file '$EXECUTABLE' not found, skipping."
        continue # Move to the next executable
    fi

    # Run ldd and extract library paths
    echo "Extracting library paths using ldd for '$EXECUTABLE'..."
    ldd_output=$(ldd "$EXECUTABLE" 2>&1)
    extracted_paths=$(echo "$ldd_output" | awk '{if ($2 == "=>") print $3; else if ($1 ~ /^\//) print $1}')

    if [ -z "$extracted_paths" ]; then
        echo "No dynamic libraries found or extracted for '$EXECUTABLE'."
        continue # Move to the next executable
    fi

    echo "Found libraries for '$EXECUTABLE':"
    echo "$extracted_paths"

    echo ""
    echo "Copying applicable libraries to '$DEST_FOLDER'..."

    # Copy each extracted library to the destination folder
    while IFS= read -r lib_path; do
        if [ -f "$lib_path" ]; then
            if $COPY_SYSTEM_LIBS || ! is_system_lib "$lib_path"; then
                # Check if the file already exists in the destination before copying
                if [ ! -f "$DEST_FOLDER/$(basename "$lib_path")" ]; then
                    echo "Copying: $lib_path"
                    cp "$lib_path" "$DEST_FOLDER/"
                    if [ $? -eq 0 ]; then
                        echo "$lib_path" >> "$LIBRARIES_LIST_FILE"
                    else
                        echo "Warning: Failed to copy $lib_path"
                    fi
                else
                    echo "Skipping (already exists in destination): $lib_path"
                    # Still add to the list if not already there, to ensure comprehensive logging
                    if ! grep -qxF "$lib_path" "$LIBRARIES_LIST_FILE"; then
                        echo "$lib_path" >> "$LIBRARIES_LIST_FILE"
                    fi
                fi
            else
                echo "Skipping system library (as -system-lib was not used): $lib_path"
            fi
        else
            echo "Warning: Library file '$lib_path' not found or is a virtual library (e.g., linux-vdso.so.1), skipping."
        fi
    done <<< "$extracted_paths"

    echo "--- Finished processing '$EXECUTABLE' ---"
    echo ""
done

echo "---"
echo "Script finished. All applicable libraries from the provided executables have been copied to '$DEST_FOLDER'."
echo "A list of successfully copied unique libraries is in '$LIBRARIES_LIST_FILE'."